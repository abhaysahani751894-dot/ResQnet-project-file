# ResQNet: Offline-First Disaster Response and Resource Coordination

ResQNet helps responders organise incident reports and relief supplies when internet access is unavailable.
Nothing in it calls an outside service: the AI model, database and emergency guide all run locally.

## Two versions
| | Server version (`server/`) | Standalone version (`standalone/`) |
|---|---|---|
| Runs on | A Linux server (Python + Flask + SQLite) | Any browser, one HTML file |
| Data | One shared board for all connected devices | Stored on each device |
| Needs | Server running and a local network (no internet) | Nothing at all |
| Sharing | Live | Export / Import a `.json` file |

Both use the same report file format, so field devices can export and the server can import.

## Features
- Incident reports with a local Naive Bayes text classifier (category, confidence, and the reasons for it)
- Separate readable rules that flag urgent phrases ("trapped", "not breathing") for human review
- Low-confidence reports fall back to the incident type chosen by the reporter and are marked for review
- Relief stock, suggested matches between reports and supplies, and a responder-approved Allocate button
- Offline emergency guide
- "Try the AI" box to test any sentence live (nothing is saved)
- Browser-side queue: reports typed while the server is unreachable are sent automatically later

## Run the server version
```bash
cd server
python3 -m pip install -r requirements.txt   # skip if Flask is already installed
bash run.sh            # this machine only
bash run.sh team       # allow other devices on the same local network
```
Open `http://127.0.0.1:5000`. Full Linux/Jupyter steps are in `DEPLOY_ON_LINUX.md`.

## Run the standalone version
Open `standalone/ResQNet_Standalone.html` in a browser. Always open it the same way each time, because browsers keep saved data separately for each address.

## Limitations
- Prototype, not an emergency dispatch service. A trained person must make every decision.
- The classifier learns from about 45 example sentences, so it is unsure on some phrases (for example collapsed buildings). Add examples in `TRAINING` (`server/classifier.py`, and the copy inside the standalone HTML) to improve it.
- No login yet: anyone with access can change a status or allocate stock. Add authentication, HTTPS and audit logs before real use.
- Flask's built-in server is for demos, not production.
