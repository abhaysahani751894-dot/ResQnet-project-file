# Deploy ResQNet on the Linux server (Jupyter) and push to GitHub

Do these steps on the hackathon server, using Jupyter's file browser and its Terminal.
Ask the organizers before installing anything or changing any settings.

## 1. Upload
In Jupyter's file browser click the **Upload** button and choose `ResQNet_Final.zip`.

## 2. Open a terminal
**File -> New -> Terminal**. Then:
```bash
unzip ResQNet_Final.zip
cd ResQNet
```

## 3. Check the server (changes nothing)
```bash
bash check_setup.sh
```
Look for: Python 3.9 or newer, Flask installed, Port 5000 free.

## 4. Install Flask (only if step 3 says it is missing)
```bash
cd server
python3 -m venv .venv
. .venv/bin/activate
pip install -r requirements.txt
cd ..
```
If the server has no internet, ask the organizers for Flask wheel files or a package mirror.

## 5. Start the app
```bash
cd server
bash run.sh
```
Leave this terminal open. If you see "Address already in use", run `RESQNET_PORT=5001 bash run.sh` instead.

## 6. Test it (open a second terminal with the + button)
```bash
curl http://127.0.0.1:5000/api/health
```
Expected: `{"app":"ResQNet","status":"ok"}`

Then test with real sentences in the "Try the AI" box:
- `Fire spreading in the market and smoke is coming from the building` -> Fire, about 97%
- `No drinking water for two days and children are thirsty` -> Water Shortage, about 99%
- `Elderly man is unconscious and needs an ambulance` -> Medical Emergency, Check urgently

## 7. Let other devices connect (only if the organizers allow it)
Stop the app with Ctrl+C, then run `bash run.sh team`. Other devices open `http://SERVER_IP:5000` with the IP the organizers give you.
Do not expose it to the public internet.

## 8. Keep it running after the terminal closes
```bash
nohup bash run.sh > resqnet.log 2>&1 &
```
Stop it later with `pkill -f server.py`.

## 9. Push to GitHub (if the server has internet and Git)
Check first: `git --version`. If Git is missing or there is no internet, use the fallback below.

Create an empty repository on github.com named `ResQNet` (leave README, .gitignore and license unticked).
GitHub no longer accepts account passwords for pushing. Create a token instead:
GitHub -> Settings -> Developer settings -> Personal access tokens -> Tokens (classic) -> Generate new token -> tick `repo` -> copy it.

From the `ResQNet` folder:
```bash
git config --global user.name "Your Name"
git config --global user.email "you@example.com"
git init
git add .
git commit -m "ResQNet: server and standalone versions"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/ResQNet.git
git push -u origin main
```
When asked for a password, paste the token (it will not show on screen).
Keep the token private, and delete it from GitHub settings after the event.

**Fallback (no Git or no internet on the server):** in Jupyter right-click `ResQNet_Final.zip` -> Download. On any laptop with internet, unzip it, open your repository on github.com, click **uploading an existing file**, drag the files in, and click **Commit changes**.

## 10. Final report
`REPORT.md` is the project report draft. Add team names, then submit it with the GitHub link.
