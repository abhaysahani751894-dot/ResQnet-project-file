"""Local text classifier for ResQNet.

A small Naive Bayes model written in plain Python, so it needs no extra
packages and no internet. It is trained on the example sentences below
every time the server starts. It is a prototype: add more examples to
TRAINING to make it better, and always let a person check the result.
"""
import math
import re
from collections import Counter

TRAINING = {
    "Flood": [
        "water is rising near homes", "river overflow flooded the village",
        "streets are waterlogged and houses are underwater", "flash flood washed away the road",
        "knee deep flood water entered our ground floor"],
    "Fire": [
        "fire spreading in the market", "smoke coming from the building",
        "house is burning and flames are spreading", "forest blaze moving towards homes",
        "gas cylinder blast started a fire"],
    "Earthquake": [
        "strong earthquake shaking buildings", "tremor felt and walls cracked",
        "aftershock after the quake people are outside", "ground shaking for a minute and houses cracked",
        "quake damaged homes in our street"],
    "Storm": [
        "cyclone with strong wind tore off roofs", "heavy storm and lightning hit the area",
        "hurricane winds knocked down trees", "storm destroyed our shelter and fences",
        "tornado warning strong winds approaching"],
    "Landslide": [
        "landslide blocked the hill road", "mudslide buried houses on the slope",
        "rockfall on the mountain path", "hillside collapsed after heavy rain",
        "soil sliding down near the village"],
    "Medical Emergency": [
        "injured people need an ambulance", "elderly man is unconscious and needs a doctor",
        "child has high fever and difficulty breathing", "severe bleeding and broken leg need medical help",
        "we need first aid and medicine for injured"],
    "Infrastructure Damage": [
        "bridge collapsed and road is blocked", "power line fell on the street",
        "building damage and cracked walls", "electric pole down and no electricity",
        "main road destroyed vehicles cannot pass"],
    "Water Shortage": [
        "no drinking water for two days", "water supply is cut and people are thirsty",
        "we need clean water for families", "wells are contaminated no safe drinking water",
        "children need water and water tanks are empty"],
    "Shelter Needed": [
        "families lost their homes and need shelter", "people sleeping outside need blankets and tents",
        "need a safe place to stay tonight", "relief camp needs space for displaced families",
        "homeless after the disaster need blankets"],
}

URGENT_TERMS = ["trapped", "missing", "unconscious", "not breathing", "severe bleeding",
                "people inside", "child missing", "life threatening", "collapsed building",
                "urgent medical", "cannot move", "drowning"]

STOP_WORDS = {"the", "a", "an", "is", "are", "and", "to", "of", "in", "on", "for", "we", "our",
              "it", "at", "with", "by", "has", "have", "need", "needs", "after", "near", "all"}


def tokenize(text):
    words = re.findall(r"[a-z]+", (text or "").lower())
    return [w for w in words if w not in STOP_WORDS and len(w) > 1]


# ---- training ----
word_counts = {}   # category -> Counter of words
vocabulary = set()
for category, sentences in TRAINING.items():
    counter = Counter()
    for sentence in sentences:
        counter.update(tokenize(sentence))
    word_counts[category] = counter
    vocabulary.update(counter)


def _log_probability(category, words):
    counter = word_counts[category]
    total = sum(counter.values())
    return sum(math.log((counter[w] + 1) / (total + len(vocabulary))) for w in words)


def classify_report(disaster_type, description, needs=""):
    text = " ".join([disaster_type, description, needs]).lower()
    words = [w for w in tokenize(text) if w in vocabulary]

    urgent_hits = [t for t in URGENT_TERMS if t in text]
    priority_flag = "Check urgently" if urgent_hits else "Standard review"
    reasons = ["Urgent phrase: " + t for t in urgent_hits]

    if not words:
        return {"category": "Needs Review", "priority_flag": priority_flag, "confidence": 0.0,
                "review_required": True,
                "reasons": "; ".join(reasons + ["No known words, so the model cannot guess"])}

    # Naive Bayes: score each category, then turn the scores into percentages
    scores = {c: _log_probability(c, words) for c in TRAINING}
    top = max(scores.values())
    exp_scores = {c: math.exp(s - top) for c, s in scores.items()}
    total = sum(exp_scores.values())
    best = max(exp_scores, key=exp_scores.get)
    confidence = exp_scores[best] / total

    matched = sorted({w for w in words if word_counts[best][w] > 0})[:4]
    if matched:
        reasons.append("Matched words: " + ", ".join(matched))

    category = best
    low_confidence = confidence < 0.6
    if low_confidence:
        reasons.append("Model is unsure, please check")
        if disaster_type in TRAINING:  # the reporter picked a known type, so use it
            category = disaster_type
            reasons.append("Used the incident type chosen by the reporter")
    return {"category": category, "priority_flag": priority_flag, "confidence": round(confidence, 2),
            "review_required": low_confidence or bool(urgent_hits), "reasons": "; ".join(reasons)}
