import sqlite3
from pathlib import Path
from datetime import datetime, timezone

# Starting stock for the demo. keywords = words in a request that match this item.
SEED_RESOURCES = [
    ("Drinking water", "water,thirst,drinking", 500, "litres"),
    ("First-aid kits", "first aid,first-aid,medical,medicine,bandage", 40, "kits"),
    ("Blankets", "blanket,cold,warm", 120, "pieces"),
    ("Food packs", "food,hungry,rice,meal", 200, "packs"),
    ("Rescue boats", "boat,rescue,trapped", 3, "boats"),
]

def connect(db_path):
    connection = sqlite3.connect(str(db_path), timeout=10)
    connection.row_factory = sqlite3.Row
    return connection

def init_db(db_path):
    Path(db_path).parent.mkdir(parents=True, exist_ok=True)
    with connect(db_path) as con:
        con.execute("""
            CREATE TABLE IF NOT EXISTS reports (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                location TEXT NOT NULL,
                disaster_type TEXT NOT NULL,
                description TEXT NOT NULL,
                needs TEXT NOT NULL DEFAULT '',
                category TEXT NOT NULL,
                priority_flag TEXT NOT NULL,
                confidence REAL NOT NULL,
                review_required INTEGER NOT NULL DEFAULT 1,
                status TEXT NOT NULL DEFAULT 'Received',
                created_at TEXT NOT NULL,
                reasons TEXT NOT NULL DEFAULT ''
            )
        """)
        try:  # older database files do not have the reasons column yet
            con.execute("ALTER TABLE reports ADD COLUMN reasons TEXT NOT NULL DEFAULT ''")
        except sqlite3.OperationalError:
            pass
        con.execute("""
            CREATE TABLE IF NOT EXISTS resources (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL UNIQUE,
                keywords TEXT NOT NULL,
                quantity INTEGER NOT NULL,
                unit TEXT NOT NULL
            )
        """)
        if con.execute("SELECT COUNT(*) FROM resources").fetchone()[0] == 0:
            con.executemany("INSERT INTO resources (name, keywords, quantity, unit) VALUES (?,?,?,?)", SEED_RESOURCES)

def create_report(db_path, location, disaster_type, description, needs,
                  category, priority_flag, confidence, review_required, reasons=""):
    created_at = datetime.now(timezone.utc).isoformat(timespec="seconds")
    with connect(db_path) as con:
        cursor = con.execute("""
            INSERT INTO reports
            (location, disaster_type, description, needs, category, priority_flag,
             confidence, review_required, status, created_at, reasons)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'Received', ?, ?)
        """, (location, disaster_type, description, needs, category, priority_flag,
              confidence, int(review_required), created_at, reasons))
        return cursor.lastrowid

def _as_dict(row):
    if row is None:
        return None
    item = dict(row)
    item["review_required"] = bool(item["review_required"])
    return item

def list_reports(db_path):
    with connect(db_path) as con:
        rows = con.execute("SELECT * FROM reports ORDER BY id DESC LIMIT 300").fetchall()
    return [_as_dict(row) for row in rows]

def get_report(db_path, report_id):
    with connect(db_path) as con:
        row = con.execute("SELECT * FROM reports WHERE id = ?", (report_id,)).fetchone()
    return _as_dict(row)

def update_report_status(db_path, report_id, status):
    with connect(db_path) as con:
        cursor = con.execute("UPDATE reports SET status = ? WHERE id = ?", (status, report_id))
        return cursor.rowcount > 0

def list_resources(db_path):
    with connect(db_path) as con:
        return [dict(r) for r in con.execute("SELECT * FROM resources ORDER BY id").fetchall()]

def use_resource(db_path, resource_id, amount):
    """Take stock out of the store. Returns the updated row, or None if there is not enough."""
    with connect(db_path) as con:
        cursor = con.execute("UPDATE resources SET quantity = quantity - ? WHERE id = ? AND quantity >= ?",
                             (amount, resource_id, amount))
        if cursor.rowcount == 0:
            return None
        return dict(con.execute("SELECT * FROM resources WHERE id = ?", (resource_id,)).fetchone())

IMPORT_FIELDS = ("location", "disaster_type", "description", "needs", "category", "priority_flag",
                 "confidence", "review_required", "status", "created_at", "reasons")

def import_reports(db_path, items):
    """Add reports from an export file. Reports we already have are skipped. Returns (added, skipped)."""
    added = skipped = 0
    with connect(db_path) as con:
        for item in items:
            if not isinstance(item, dict) or not all(item.get(k) for k in ("location", "description", "created_at")):
                skipped += 1
                continue
            exists = con.execute("SELECT 1 FROM reports WHERE created_at=? AND location=? AND description=?",
                                 (item["created_at"], item["location"], item["description"])).fetchone()
            if exists:
                skipped += 1
                continue
            con.execute("""INSERT INTO reports (location, disaster_type, description, needs, category, priority_flag,
                           confidence, review_required, status, created_at, reasons) VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
                        (str(item["location"])[:160], str(item.get("disaster_type", "Other / Unsure"))[:50],
                         str(item["description"])[:2000], str(item.get("needs", ""))[:500],
                         str(item.get("category", "Needs Review")), str(item.get("priority_flag", "Standard review")),
                         float(item.get("confidence", 0) or 0), int(bool(item.get("review_required", True))),
                         item.get("status") if item.get("status") in ("Received", "Assigned", "In Progress", "Resolved") else "Received",
                         str(item["created_at"]), str(item.get("reasons", ""))))
            added += 1
    return added, skipped
