import os
from pathlib import Path
from flask import Flask, jsonify, request, send_from_directory
from database import init_db, create_report, list_reports, update_report_status, get_report, list_resources, use_resource, import_reports
from classifier import classify_report

BASE_DIR = Path(__file__).resolve().parent
PUBLIC_DIR = BASE_DIR / "public"
DB_PATH = Path(os.environ.get("RESQNET_DB_PATH", str(BASE_DIR / "resqnet.db")))

app = Flask(__name__, static_folder=str(PUBLIC_DIR), static_url_path="/static")
app.config["MAX_CONTENT_LENGTH"] = 2 * 1024 * 1024
init_db(DB_PATH)

ALLOWED_STATUSES = {"Received", "Assigned", "In Progress", "Resolved"}

@app.get("/")
def home():
    return send_from_directory(PUBLIC_DIR, "index.html")

@app.get("/api/health")
def health():
    return jsonify({"status": "ok", "app": "ResQNet"})

@app.get("/api/reports")
def reports():
    return jsonify({"reports": list_reports(DB_PATH)})

@app.post("/api/reports")
def submit_report():
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        return jsonify({"error": "Send report details as JSON."}), 400
    location = str(data.get("location", "")).strip()
    disaster_type = str(data.get("disaster_type", "")).strip()
    description = str(data.get("description", "")).strip()
    needs = str(data.get("needs", "")).strip()
    if not location or not disaster_type or not description:
        return jsonify({"error": "Location, disaster type, and description are required."}), 400
    if len(location) > 160 or len(disaster_type) > 50 or len(description) > 2000 or len(needs) > 500:
        return jsonify({"error": "One or more fields are too long."}), 400
    result = classify_report(disaster_type, description, needs)
    report_id = create_report(
        DB_PATH, location, disaster_type, description, needs,
        result["category"], result["priority_flag"], result["confidence"],
        result["review_required"], result["reasons"]
    )
    return jsonify({"report": get_report(DB_PATH, report_id)}), 201

@app.patch("/api/reports/<int:report_id>")
def change_status(report_id):
    # Demo-only endpoint: add authentication and authorization before real use.
    data = request.get_json(silent=True)
    status = str(data.get("status", "")).strip() if isinstance(data, dict) else ""
    if status not in ALLOWED_STATUSES:
        return jsonify({"error": "Invalid status."}), 400
    if not update_report_status(DB_PATH, report_id, status):
        return jsonify({"error": "Report not found."}), 404
    return jsonify({"report": get_report(DB_PATH, report_id)})

@app.get("/api/resources")
def resources():
    return jsonify({"resources": list_resources(DB_PATH)})

@app.get("/api/suggestions")
def suggestions():
    """Match open reports to items in stock. These are only suggestions for a human to approve."""
    stock = list_resources(DB_PATH)
    found = []
    for report in list_reports(DB_PATH):
        if report["status"] == "Resolved":
            continue
        text = (report["needs"] + " " + report["description"]).lower()
        for item in stock:
            if any(word in text for word in item["keywords"].split(",")):
                found.append({"report_id": report["id"], "location": report["location"],
                              "urgent": report["priority_flag"] == "Check urgently",
                              "resource_id": item["id"], "resource": item["name"],
                              "available": item["quantity"], "unit": item["unit"]})
    found.sort(key=lambda s: (not s["urgent"], s["report_id"]))
    return jsonify({"suggestions": found})

@app.post("/api/resources/<int:resource_id>/use")
def allocate(resource_id):
    data = request.get_json(silent=True) or {}
    try:
        amount = int(data.get("amount", 0))
    except (TypeError, ValueError):
        amount = 0
    if amount <= 0:
        return jsonify({"error": "Enter a number above zero."}), 400
    updated = use_resource(DB_PATH, resource_id, amount)
    if updated is None:
        return jsonify({"error": "Not enough stock left."}), 400
    return jsonify({"resource": updated})

@app.get("/api/guide")
def guide():
    text = (BASE_DIR / "guides" / "emergency-guide.txt").read_text(encoding="utf-8")
    return jsonify({"guide": text})

@app.post("/api/classify")
def try_classifier():
    """Run the model on some text without saving anything (used by the 'Try the AI' box)."""
    data = request.get_json(silent=True) or {}
    text = str(data.get("text", "")).strip()[:2000]
    if not text:
        return jsonify({"error": "Type a sentence first."}), 400
    return jsonify(classify_report("", text, ""))

@app.get("/api/export")
def export_reports():
    return jsonify({"app": "ResQNet", "reports": list_reports(DB_PATH)})

@app.post("/api/import")
def import_file():
    data = request.get_json(silent=True)
    if not isinstance(data, dict) or not isinstance(data.get("reports"), list):
        return jsonify({"error": "This is not a ResQNet export file."}), 400
    added, skipped = import_reports(DB_PATH, data["reports"][:1000])
    return jsonify({"added": added, "skipped": skipped})

@app.errorhandler(413)
def request_too_large(_error):
    return jsonify({"error": "Request is too large."}), 413

if __name__ == "__main__":
    host = os.environ.get("RESQNET_HOST", "127.0.0.1")
    port = int(os.environ.get("RESQNET_PORT", "5000"))
    app.run(host=host, port=port, debug=False)
