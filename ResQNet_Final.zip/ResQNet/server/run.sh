#!/bin/bash
# Start ResQNet. Usage: ./run.sh          (this machine only)
#                       ./run.sh team     (let devices on the same local network connect)
cd "$(dirname "$0")"
[ -d .venv ] && . .venv/bin/activate
[ "$1" = "team" ] && export RESQNET_HOST=0.0.0.0
python3 server.py
