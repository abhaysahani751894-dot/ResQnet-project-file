const form = document.querySelector("#report-form");
const message = document.querySelector("#form-message");
const submitButton = document.querySelector("#submit-button");
const reportsList = document.querySelector("#reports-list");
const connectionStatus = document.querySelector("#connection-status");

function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, char => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  }[char]));
}
function prettyDate(value) {
  try { return new Date(value).toLocaleString(); } catch { return value; }
}
function reportCard(r) {
  const urgent = r.priority_flag === "Check urgently";
  const needs = r.needs ? `<p><strong>Needs:</strong> ${escapeHtml(r.needs)}</p>` : "";
  const options = ["Received", "Assigned", "In Progress", "Resolved"].map(s =>
    `<option ${r.status === s ? "selected" : ""}>${s}</option>`).join("");
  return `<article class="report-card"><h3>#${r.id} · ${escapeHtml(r.category)}</h3>
  <div class="report-meta">${escapeHtml(r.location)} · ${escapeHtml(r.disaster_type)}<br>${escapeHtml(prettyDate(r.created_at))}</div>
  <div class="pills"><span class="pill ${urgent ? "urgent" : ""}">${escapeHtml(r.priority_flag)}</span>
  ${r.review_required ? '<span class="pill review">Human review needed</span>' : ""}
  <span class="pill">${escapeHtml(r.status)}</span></div>
  <p class="report-description">${escapeHtml(r.description)}</p>${needs}
  <p class="why">Why: ${escapeHtml(r.reasons || "n/a")}</p>
  <p class="report-meta">Model confidence: ${Math.round(Number(r.confidence)*100)}% · prototype, needs human check</p>
  <div class="status-row"><label for="status-${r.id}">Status</label><select id="status-${r.id}" data-report-id="${r.id}" aria-label="Update status for report ${r.id}">${options}</select></div></article>`;
}
async function loadReports() {
  try {
    const response = await fetch("/api/reports");
    if (!response.ok) throw new Error("Server response error");
    const data = await response.json();
    const reports = data.reports || [];
    reportsList.innerHTML = reports.length ? reports.map(reportCard).join("") : '<p class="empty">No reports yet. Submit a fictional incident to start the demo.</p>';
    document.querySelector("#total-count").textContent = reports.length;
    document.querySelector("#urgent-count").textContent = reports.filter(r => r.priority_flag === "Check urgently").length;
    document.querySelector("#review-count").textContent = reports.filter(r => r.review_required).length;
    connectionStatus.textContent = "Connected to server";
  } catch {
    connectionStatus.textContent = "Server unavailable";
    reportsList.innerHTML = '<p class="empty">Could not load reports. Check the server connection and refresh.</p>';
  }
}
// Reports typed while the server is unreachable wait here (in the browser) and are sent later.
const QUEUE_KEY = "resqnet-pending";
const getQueue = () => { try { return JSON.parse(localStorage.getItem(QUEUE_KEY)) || []; } catch { return []; } };
const saveQueue = q => localStorage.setItem(QUEUE_KEY, JSON.stringify(q));
function showQueue() {
  const n = getQueue().length;
  document.querySelector("#queue-status").textContent = n ? `${n} report(s) waiting to send · ` : "";
}
async function sendReport(payload) {
  const response = await fetch("/api/reports", {method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify(payload)});
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || "Could not submit report.");
  return data.report;
}
async function flushQueue() {
  const left = [];
  for (const item of getQueue()) {
    try { await sendReport(item); }
    catch (error) { if (error instanceof TypeError) left.push(item); }  // TypeError = server not reachable
  }
  saveQueue(left); showQueue(); loadAll();
}
form.addEventListener("submit", async event => {
  event.preventDefault(); message.textContent = ""; submitButton.disabled = true;
  const payload = Object.fromEntries(new FormData(form).entries());
  try {
    const report = await sendReport(payload);
    form.reset(); message.textContent = `Report #${report.id} saved. Please have a responder review its classification.`;
    await loadAll();
  } catch (error) {
    if (error instanceof TypeError) {
      saveQueue([...getQueue(), payload]); form.reset(); showQueue();
      message.textContent = "Server not reachable. Report kept on this device and will send automatically.";
    } else { message.textContent = error.message; }
  } finally { submitButton.disabled = false; }
});
setInterval(flushQueue, 10000);
window.addEventListener("online", flushQueue);

async function loadResources() {
  try {
    const stock = (await (await fetch("/api/resources")).json()).resources;
    document.querySelector("#resources-list").innerHTML = stock.map(r =>
      `<div class="resource"><b>${r.quantity}</b><small>${escapeHtml(r.unit)} of ${escapeHtml(r.name)}</small></div>`).join("");
    const tips = (await (await fetch("/api/suggestions")).json()).suggestions;
    document.querySelector("#suggestions-list").innerHTML = tips.length ? tips.map(t =>
      `<div class="suggestion ${t.urgent ? "urgent" : ""}"><span>Report #${t.report_id} (${escapeHtml(t.location)}) could use <b>${escapeHtml(t.resource)}</b> · ${t.available} ${escapeHtml(t.unit)} left</span>
      <button data-resource="${t.resource_id}">Allocate</button></div>`).join("") : '<p class="empty">No suggestions yet.</p>';
  } catch {}
}
document.querySelector("#suggestions-list").addEventListener("click", async event => {
  const button = event.target.closest("button[data-resource]");
  if (!button) return;
  const amount = parseInt(prompt("How many units to allocate?", "1"), 10);
  if (!amount) return;
  const response = await fetch(`/api/resources/${button.dataset.resource}/use`, {method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify({amount})});
  if (!response.ok) alert((await response.json()).error);
  loadResources();
});
async function loadGuide() {
  const box = document.querySelector("#guide-text");
  try { box.textContent = (await (await fetch("/api/guide")).json()).guide; }
  catch { box.textContent = "Guide unavailable. Open the page once while connected to the server to save it."; }
}
function loadAll() { loadReports(); loadResources(); }

reportsList.addEventListener("change", async event => {
  const select = event.target.closest("select[data-report-id]");
  if (!select) return;
  select.disabled = true;
  try {
    const response = await fetch(`/api/reports/${select.dataset.reportId}`, {method:"PATCH", headers:{"Content-Type":"application/json"}, body:JSON.stringify({status:select.value})});
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Status update failed.");
    await loadAll();
  } catch (error) { alert(error.message || "Could not update status."); await loadReports(); }
  finally { select.disabled = false; }
});
document.querySelector("#refresh-button").addEventListener("click", loadAll);
if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => navigator.serviceWorker.register("/static/sw.js").catch(() => {}));
}
// Export the board to a file / import a file from another device
document.querySelector("#export-button").addEventListener("click", async () => {
  try {
    const data = await (await fetch("/api/export")).json();
    const link = document.createElement("a");
    link.href = URL.createObjectURL(new Blob([JSON.stringify(data, null, 2)], {type: "application/json"}));
    link.download = "resqnet-reports-" + new Date().toISOString().slice(0, 10) + ".json";
    link.click();
  } catch { alert("Could not export. Is the server running?"); }
});
document.querySelector("#import-button").addEventListener("click", () => document.querySelector("#import-file").click());
document.querySelector("#import-file").addEventListener("change", async event => {
  const file = event.target.files[0]; if (!file) return;
  try {
    const response = await fetch("/api/import", {method:"POST", headers:{"Content-Type":"application/json"}, body: await file.text()});
    const data = await response.json();
    alert(response.ok ? `Imported ${data.added} report(s), skipped ${data.skipped} already here.` : data.error);
    loadAll();
  } catch { alert("Could not import that file."); }
  event.target.value = "";
});
// "Try the AI" box: ask the model, show the answer, save nothing
document.querySelector("#ai-button").addEventListener("click", async () => {
  const out = document.querySelector("#ai-result");
  const text = document.querySelector("#ai-text").value;
  try {
    const response = await fetch("/api/classify", {method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify({text})});
    const r = await response.json();
    out.textContent = response.ok ? `${r.category} · ${Math.round(r.confidence*100)}% confidence · ${r.priority_flag}. ${r.reasons}` : r.error;
  } catch { out.textContent = "Server not reachable."; }
});
loadAll(); loadGuide(); showQueue(); flushQueue();
