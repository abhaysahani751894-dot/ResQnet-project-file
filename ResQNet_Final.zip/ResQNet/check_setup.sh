#!/bin/bash
# Read-only checks. Installs nothing and changes nothing.
echo "Machine type : $(uname -m)"
echo "Python       : $(python3 --version 2>&1)"
python3 -c "import flask; print('Flask        : installed')" 2>/dev/null || echo "Flask        : NOT installed (see step 4 in DEPLOY_ON_LINUX.md)"
python3 -c "import sqlite3; print('SQLite       :', sqlite3.sqlite_version)"
echo "Git          : $(git --version 2>&1)"
python3 - <<'PY'
import socket
s = socket.socket()
print("Port 5000    :", "IN USE (use another port)" if s.connect_ex(("127.0.0.1", 5000)) == 0 else "free")
PY
