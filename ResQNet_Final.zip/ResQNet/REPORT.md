# ResQNet: Final Project Report

**Team:** (add names)  **Event:** (add event name)  **Platform:** Linux server, Python / Flask / SQLite

## 1. Problem
During floods, earthquakes and fires, emergency requests arrive from many places at once. Responders struggle to spot urgent reports, track available supplies and coordinate help, and internet access is often down exactly when it is needed.

## 2. Solution
ResQNet is a lightweight web application that works with no internet connection. It sorts incoming reports with a locally running text classifier, flags urgent cases with readable rules, tracks relief supplies, and keeps an emergency guide available offline. It supports responders and does not replace them: every decision stays with a trained person.

## 3. Architecture
- **Frontend:** HTML, CSS, JavaScript (no outside libraries, fonts or CDNs)
- **Backend:** Python with Flask
- **Database:** SQLite (a single local file)
- **AI model:** Naive Bayes text classifier written in plain Python, trained at start-up on about 45 example sentences across 9 categories
- **Rules:** a separate list of urgent phrases (for example "trapped", "not breathing") that raises a "Check urgently" flag
- **Two versions:** a shared server version, and a standalone single-file version that runs in any browser and shares data by Export / Import

## 4. How offline operation works
The server and every file it serves are local. Nothing calls an external API. The browser keeps a queue of reports typed while the server is unreachable and sends them automatically when it returns. The standalone version needs no server at all.

## 5. Testing performed
Tested on the server version and the standalone version with the same inputs. Both gave identical results.

| Input | Result | Confidence |
|---|---|---|
| Flood: "Water is rising near homes and we need drinking water" | Water Shortage | 90% |
| Earthquake: "Building collapsed, people trapped inside" | Earthquake (type chosen by reporter, model unsure), Check urgently | 20% |
| "Elderly man is unconscious and not breathing" | Medical Emergency, Check urgently | 94% |
| "Families lost their homes and are sleeping outside..." | Shelter Needed | 98% |
| "help" (Flood chosen) | Flood, marked for human review | 29% |
| Try the AI: "Fire spreading in the market and smoke is coming from the building" | Fire | 97% |

Also verified: resource suggestions, stock allocation, status changes, emergency guide display, and the Export / Import file format.

## 6. Responsible-AI measures
- The model shows its confidence and the words that drove the result.
- Low-confidence results are marked "Human review needed".
- Urgency comes from visible rules, not from the model.
- Resource suggestions require a responder to approve them.
- The interface states that it is a prototype and not an emergency service.

## 7. Limitations
- Small training set: weak on phrases it has few examples of (for example collapsed buildings).
- No login or access control yet.
- Flask's development server is not for production use.
- The standalone version has no live sync; sharing needs a file transfer.
- The emergency guide is generic and must be replaced with officially approved guidance.

## 8. Future work
Responder login and roles, a larger and locally reviewed training set, support for local languages, map view, mesh or radio links for device-to-device sync, and evaluation with real emergency-management staff.
